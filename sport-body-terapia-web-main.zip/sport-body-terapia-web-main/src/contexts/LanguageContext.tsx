import React, { createContext, useContext, useState, ReactNode } from 'react';

export type Language = 'sk' | 'en';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  sk: {
    // Navigation
    'nav.home': 'Domov',
    'nav.about': 'O Mne',
    'nav.services': 'Čo Liečime',
    'nav.resources': 'Zdroje pre Pacientov',
    'nav.contact': 'Kontakt',
    'nav.book': 'Objednajte sa',
    
    // Hero Section
    'hero.title': 'Globálne skúsenosti. Individuálny prístup. Váš liečebný plán.',
    'hero.subtitle': 'Kombinujem desaťročia globálnych skúseností a súčasné najlepšie výskumné postupy, aby som plne porozumel vášmu problému a pomohol vám zotaviť sa.',
    'hero.cta': 'Objednajte sa dnes',
    
    // Services
    'services.title': 'Naše Služby',
    'services.musculoskeletal': 'Muskuloskeletálne poruchy',
    'services.musculoskeletal.desc': 'Komplexná liečba problémov s kostami, svalmi a kĺbmi',
    'services.postop': 'Pooperačná rehabilitácia',
    'services.postop.desc': 'Špecializovaná starostlivosť po chirurgických zákrokoch',
    'services.sports': 'Športové zranenia',
    'services.sports.desc': 'Odborná liečba a prevencia športových úrazov',
    
    // About
    'about.title': 'André Heynes, Fyzioterapeut',
    'about.subtitle': '25+ rokov globálnych skúseností',
    'about.philosophy': 'Vyrastajúc v Južnej Afrike, som sa naučil, že osobná interakcia, založená na výskume a poskytovaní cvičení, môže mať dopad nielen na človeka, ale aj na jeho okolie.',
    'about.learn-more': 'Dozvedieť sa viac',
    
    // Contact
    'contact.title': 'Kontaktujte nás',
    'contact.subtitle': 'Začnite svoju cestu k zotaveniu už dnes. Kontaktujte nás pre konzultáciu.',
    'contact.form.title': 'Objednajte sa na konzultáciu',
    'contact.form.name': 'Meno',
    'contact.form.email': 'Email',
    'contact.form.phone': 'Telefónne číslo',
    'contact.form.message': 'Vaša správa',
    'contact.form.placeholder': 'Opíšte svoj problém alebo otázku...',
    'contact.form.submit': 'Odoslať správu',
    'contact.info.title': 'Kontaktné informácie',
    'contact.address': 'Adresa',
    'contact.phone': 'Telefón',
    'contact.email': 'Email',
    'contact.hours': 'Ordinačné hodiny',
    'contact.hours.weekdays': 'Pondelok - Piatok: 8:00 - 18:00',
    'contact.hours.saturday': 'Sobota: 9:00 - 14:00',
    'contact.hours.sunday': 'Nedeľa: Zatvorené',
    'contact.map.title': 'Mapa lokality',
    'contact.map.subtitle': 'Dubnica nad Váhom, Slovakia',
    'contact.success.title': 'Správa odoslaná!',
    'contact.success.description': 'Kontaktujeme vás čo najskôr.',
    
    // Footer
    'footer.contact': 'Kontakt',
    'footer.address': 'Štúrova 1532/92, 018 41 Dubnica nad Váhom, Slovensko',
    'footer.follow': 'Sledujte nás',
    'footer.rights': 'Všetky práva vyhradené.',
    'footer.description': 'Profesionálna fyzioterapia s globálnymi skúsenosťami v srdci Slovenska.',
    
    // Body parts for interactive map
    'body.head': 'Hlava',
    'body.neck': 'Krk',
    'body.shoulder': 'Rameno',
    'body.arm': 'Ruka',
    'body.back': 'Chrbát',
    'body.knee': 'Koleno',
    'body.ankle': 'Členok',
    'body.elbow': 'Lakeť',
    'body.wrist': 'Zápästie',
    'body.hip': 'Bedro',
    'body.leg': 'Noha',
    
    // Conditions
    'conditions.headaches': 'Bolesti hlavy',
    'conditions.neck-pain': 'Bolesť krku',
    'conditions.shoulder-impingement': 'Impingement ramena',
    'conditions.back-pain': 'Bolesť chrbta',
    'conditions.knee-pain': 'Bolesť kolena',
    'conditions.ankle-sprain': 'Podvrtnutie členka',
    
    // Patient Resources
    'resources.title': 'Zdroje pre Pacientov',
    'resources.subtitle': 'Užitočné informácie a návody na podporu vášho zotavenia a celkového zdravia',
    'resources.newsletter.title': 'Odoberajte náš newsletter',
    'resources.newsletter.subtitle': 'Dostávajte najnovšie zdravotné tipy, cvičenia a informácie priamo do vašej e-mailovej schránky.',
    'resources.newsletter.email': 'Váš email',
    'resources.newsletter.subscribe': 'Odoberať',
    'resources.read-more': 'Čítať viac',
    
    // Interactive Map
    'map.select-body-part': 'Vyberte časť tela',
    'map.select-instruction': 'Kliknite na ktorúkoľvek časť tela v diagrame, aby ste videli špecifické stavy, ktoré liečime v tej oblasti.',
    'map.conditions-title': 'Stavy, ktoré liečime:',
    'map.consultation-note': 'Každý stav vyžaduje individuálny prístup. Kontaktujte nás pre osobnú konzultáciu a vytvorenie vášho liečebného plánu.',
    'map.instructions': 'Kliknite na časť tela a dozviete sa viac o stavoch, ktoré liečime',
    
    // Cookie Consent
    'cookies.title': 'Súbory Cookie',
    'cookies.message': 'Používame súbory cookie na zlepšenie vašej browserovacej skúsenosti a na analýzu návštevnosti. Kliknutím na "Prijať" súhlasíte s používaním všetkých súborov cookie.',
    'cookies.accept': 'Prijať všetky',
    'cookies.decline': 'Odmietnuť',
    
    // GDPR Compliance
    'gdpr.title': 'GDPR Súlad',
    'gdpr.description': 'Informácie o tom, ako spracúvame vaše osobné údaje v súlade s GDPR',
    'gdpr.subtitle': 'Vaše súkromie je naša priorita. Dozviete sa, ako spracúvame vaše osobné údaje.',
    'gdpr.last-updated': 'Posledná aktualizácia',
    'gdpr.data-controller.title': 'Správca údajov',
    'gdpr.data-controller.content': '<p>Správcom vašich osobných údajov je <strong>Šport & Body Terapia</strong>, so sídlom v Dubnica nad Váhom, Slovensko.</p><p>Kontakt: info@sportbodyterapia.sk</p>',
    'gdpr.data-collected.title': 'Aké údaje zbierame',
    'gdpr.data-collected.content': '<ul><li>Meno a priezvisko</li><li>Emailová adresa</li><li>Telefónne číslo</li><li>Zdravotné informácie relevantné pre liečbu</li><li>Údaje o návštevách a liečbe</li></ul>',
    'gdpr.legal-basis.title': 'Právny základ spracovania',
    'gdpr.legal-basis.content': '<p>Vaše údaje spracúvame na základe:</p><ul><li><strong>Súhlas</strong> - pre marketingové komunikácie</li><li><strong>Plnenie zmluvy</strong> - pre poskytovanie zdravotnej starostlivosti</li><li><strong>Oprávnený záujem</strong> - pre zlepšovanie našich služieb</li></ul>',
    'gdpr.your-rights.title': 'Vaše práva',
    'gdpr.your-rights.content': '<ul><li>Právo na prístup k údajom</li><li>Právo na opravu údajov</li><li>Právo na vymazanie údajov</li><li>Právo na prenosnosť údajov</li><li>Právo na obmedzenie spracovania</li><li>Právo vzniesť námietku</li></ul>',
    'gdpr.contact.title': 'Kontakt pre otázky o GDPR',
    'gdpr.contact.description': 'Pre akékoľvek otázky týkajúce sa spracovania osobných údajov nás môžete kontaktovať:',
    
    // Privacy Policy
    'privacy.title': 'Zásady ochrany osobných údajov',
    'privacy.description': 'Informácie o našich zásadách ochrany súkromia a spracovania osobných údajov',
    'privacy.subtitle': 'Transparentné informácie o tom, ako chránime vaše súkromie',
    'privacy.last-updated': 'Posledná aktualizácia',
    'privacy.data-collection.title': 'Zber údajov',
    'privacy.data-collection.content': '<p>Zbierame iba údaje potrebné na poskytovanie našich služieb:</p><ul><li>Identifikačné údaje (meno, adresa)</li><li>Kontaktné údaje (telefón, email)</li><li>Zdravotné údaje relevantné pre liečbu</li><li>Technické údaje (IP adresa, cookies)</li></ul>',
    'privacy.data-usage.title': 'Použitie údajov',
    'privacy.data-usage.content': '<p>Vaše údaje používame výlučne na:</p><ul><li>Poskytovanie zdravotnej starostlivosti</li><li>Komunikáciu s pacientmi</li><li>Zlepšovanie kvality služieb</li><li>Dodržiavanie právnych povinností</li></ul>',
    'privacy.data-sharing.title': 'Zdieľanie údajov',
    'privacy.data-sharing.content': '<p>Vaše údaje nezdieľame s tretími stranami, okrem prípadov:</p><ul><li>So súhlasom pacienta</li><li>Pre zdravotné účely (odporúčania k špecialistom)</li><li>Na základe právnej povinnosti</li></ul>',
    'privacy.data-security.title': 'Bezpečnosť údajov',
    'privacy.data-security.content': '<p>Implementujeme prísne bezpečnostné opatrenia:</p><ul><li>Šifrovanie údajov</li><li>Pravidelné bezpečnostné audity</li><li>Obmedzený prístup k údajom</li><li>Bezpečné uloženie dokumentácie</li></ul>',
    'privacy.data-retention.title': 'Doba uchovávania',
    'privacy.data-retention.content': '<p>Údaje uchováváme:</p><ul><li>Zdravotné záznamy: podľa platnej legislatívy</li><li>Kontaktné údaje: do odvolania súhlasu</li><li>Technické údaje: maximálne 2 roky</li></ul>',
    'privacy.cookies.title': 'Súbory Cookie',
    'privacy.cookies.content': '<p>Používame súbory cookie na:</p><ul><li>Zabezpečenie funkčnosti webu</li><li>Analýza návštevnosti</li><li>Zlepšenie používateľskej skúsenosti</li></ul><p>Podrobné informácie nájdete v našej <a href="/cookie-policy" class="text-brand-teal">Cookie Policy</a>.</p>',
    
    // Terms of Service
    'terms.title': 'Obchodné podmienky',
    'terms.description': 'Podmienky používania našich služieb a webovej stránky',
    'terms.subtitle': 'Pravidlá a podmienky pre používanie našich služieb',
    'terms.last-updated': 'Posledná aktualizácia',
    'terms.acceptance.title': 'Prijatie podmienok',
    'terms.acceptance.content': '<p>Používaním našich služieb súhlasíte s týmito obchodnými podmienkami. Ak nesúhlasíte s ktoroukoľvek časťou, nepoužívajte naše služby.</p>',
    'terms.services.title': 'Naše služby',
    'terms.services.content': '<p>Poskytujeme:</p><ul><li>Fyzioterapeutické služby</li><li>Rehabilitačné programy</li><li>Poradenstvo v oblasti zdravia</li><li>Preventívne programy</li></ul><p>Všetky služby sú poskytované kvalifikovanými odborníkmi.</p>',
    'terms.responsibilities.title': 'Zodpovednosti klienta',
    'terms.responsibilities.content': '<ul><li>Poskytnutie presných zdravotných informácií</li><li>Dodržiavanie terapeutických odporúčaní</li><li>Včasné zrušenie termínov</li><li>Úhrada za poskytnuté služby</li></ul>',
    'terms.liability.title': 'Obmedzenie zodpovednosti',
    'terms.liability.content': '<p>Naša zodpovednosť je obmedzená na:</p><ul><li>Poskytovanie služieb s odbornou starostlivosťou</li><li>Dodržiavanie platných štandardov</li><li>Ochranu dôverných informácií</li></ul><p>Nie sme zodpovední za výsledky liečby, ktoré závisia od individuálnych faktorov.</p>',
    'terms.modifications.title': 'Zmeny podmienok',
    'terms.modifications.content': '<p>Vyhradzujeme si právo upraviť tieto podmienky. O zmenách budeme informovať:</p><ul><li>Na našej webovej stránke</li><li>Emailom registrovaným klientom</li><li>V našej ordinácii</li></ul>',
    
    // Medical Disclaimer
    'medical.title': 'Zdravotné vylúčenie zodpovednosti',
    'medical.description': 'Dôležité informácie o našich zdravotných službách a obmedzeniach',
    'medical.subtitle': 'Dôležité informácie pred využitím našich služieb',
    'medical.last-updated': 'Posledná aktualizácia',
    'medical.important-notice.title': 'Dôležité upozornenie',
    'medical.important-notice.content': 'Toto nie je náhrada za lekársku diagnostiku alebo liečbu. V prípade závažných zdravotných problémov sa obráťte na svojho lekára.',
    'medical.disclaimer.title': 'Zdravotné vylúčenie',
    'medical.disclaimer.content': '<p>Informácie na tejto stránke slúžia výlučne na informačné účely a nie sú určené na:</p><ul><li>Diagnostiku zdravotných stavov</li><li>Lekárske poradenstvo</li><li>Nahradenie konzultácie s lekárom</li><li>Predpis liekov alebo liečby</li></ul>',
    'medical.professional-relationship.title': 'Profesionálny vzťah',
    'medical.professional-relationship.content': '<p>Návšteva našej webstránky nevytvára vzťah lekár-pacient. Terapeutický vzťah vzniká až po:</p><ul><li>Osobnej konzultácii</li><li>Vyhodnotení zdravotného stavu</li><li>Písomnom súhlase pacienta</li></ul>',
    'medical.emergency.title': 'Núdzové situácie',
    'medical.emergency.content': '<p><strong>V prípade zdravotnej núdze volajte 155 alebo sa obráťte na najbližšie zdravotnícke zariadenie.</strong></p><p>Naše služby nie sú určené na riešenie akútnych zdravotných stavov.</p>',
    'medical.treatment-results.title': 'Výsledky liečby',
    'medical.treatment-results.content': '<p>Výsledky fyzioterapie sa môžu líšiť v závislosti na:</p><ul><li>Individuálnom zdravotnom stave</li><li>Závažnosti problému</li><li>Dodržiavaní terapeutických odporúčaní</li><li>Celkovom zdravotnom stave pacienta</li></ul><p>Nezaručujeme konkrétne výsledky liečby.</p>',
    'medical.individual-assessment.title': 'Individuálne posúdenie',
    'medical.individual-assessment.content': '<p>Každý pacient je jedinečný a vyžaduje individuálny prístup. Odporúčania a cvičenia musia byť vždy prispôsobené konkrétnemu stavu a potrebám pacienta.</p>',
    
    // Cookie Policy
    'cookies.policy.title': 'Zásady používania súborov Cookie',
    'cookies.policy.description': 'Informácie o tom, ako používame súbory cookie na našej webstránke',
    'cookies.policy.subtitle': 'Podrobné informácie o súboroch cookie, ktoré používame',
    'cookies.policy.last-updated': 'Posledná aktualizácia',
    'cookies.what-are.title': 'Čo sú súbory cookie?',
    'cookies.what-are.content': 'Súbory cookie sú malé textové súbory, ktoré sa ukladajú vo vašom prehliadači pri návšteve webstránky. Pomáhajú nám zabezpečiť funkčnosť stránky a zlepšiť vašu používateľskú skúsenosť.',
    'cookies.types.title': 'Typy súborov cookie',
    'cookies.necessary.title': 'Nevyhnutné súbory cookie',
    'cookies.necessary.content': '<p>Tieto súbory cookie sú nevyhnutné pre základnú funkčnosť webstránky a nemožno ich vypnúť.</p><ul><li>Prihlásenie a autentifikácia</li><li>Bezpečnostné funkcie</li><li>Základné navigačné funkcie</li></ul>',
    'cookies.analytics.title': 'Analytické súbory cookie',
    'cookies.analytics.content': '<p>Pomáhajú nám porozumieť tomu, ako návštevníci používajú našu stránku.</p><ul><li>Google Analytics</li><li>Štatistiky návštevnosti</li><li>Analýza používania stránky</li></ul>',
    'cookies.functional.title': 'Funkčné súbory cookie',
    'cookies.functional.content': '<p>Zlepšujú funkčnosť a personalizáciu webstránky.</p><ul><li>Jazykové preferencie</li><li>Rozloženie stránky</li><li>Používateľské nastavenia</li></ul>',
    'cookies.management.title': 'Správa súborov cookie',
    'cookies.management.content': '<p>Súbory cookie môžete spravovať nasledovnými spôsobmi:</p><ul><li><strong>Nastavenia prehliadača:</strong> Väčšina prehliadačov umožňuje blokovanie alebo vymazanie súborov cookie</li><li><strong>Naše nastavenia:</strong> Môžete upraviť svoje preferencie pre súbory cookie</li><li><strong>Automatické vymazanie:</strong> Súbory cookie môžete nastaviť na automatické vymazanie</li></ul><p>Upozorňujeme, že vypnutie súborov cookie môže ovplyvniť funkčnosť webstránky.</p>',
    
    // Footer policy links
    'footer.policies': 'Zásady',
    'footer.gdpr': 'GDPR',
    'footer.privacy': 'Ochrana súkromia',
    'footer.terms': 'Obchodné podmienky',
    'footer.medical-disclaimer': 'Zdravotné vylúčenie',
    'footer.cookies': 'Cookie Policy'
  },
  en: {
    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About Me',
    'nav.services': 'What We Treat',
    'nav.resources': 'Patient Resources',
    'nav.contact': 'Contact',
    'nav.book': 'Book Appointment',
    
    // Hero Section
    'hero.title': 'Global experience. Individual approach. Your treatment plan.',
    'hero.subtitle': 'I combine decades of global experience with current best research practices to fully understand your problem and help you recover.',
    'hero.cta': 'Book Today',
    
    // Services
    'services.title': 'Our Services',
    'services.musculoskeletal': 'Musculoskeletal Disorders',
    'services.musculoskeletal.desc': 'Comprehensive treatment for bone, muscle, and joint problems',
    'services.postop': 'Post-Operative Rehabilitation',
    'services.postop.desc': 'Specialized care following surgical procedures',
    'services.sports': 'Sports Injuries',
    'services.sports.desc': 'Expert treatment and prevention of athletic injuries',
    
    // About
    'about.title': 'André Heynes, Physiotherapist',
    'about.subtitle': '25+ years of global experience',
    'about.philosophy': 'Growing up in South Africa, I learned that personal interaction, based on research and the provision of exercises, can have an impact not only on the person but also those around them.',
    'about.learn-more': 'Learn More',
    
    // Contact
    'contact.title': 'Contact Us',
    'contact.subtitle': 'Start your journey to recovery today. Contact us for a consultation.',
    'contact.form.title': 'Book a Consultation',
    'contact.form.name': 'Name',
    'contact.form.email': 'Email',
    'contact.form.phone': 'Phone Number',
    'contact.form.message': 'Your Message',
    'contact.form.placeholder': 'Describe your problem or question...',
    'contact.form.submit': 'Send Message',
    'contact.info.title': 'Contact Information',
    'contact.address': 'Address',
    'contact.phone': 'Phone',
    'contact.email': 'Email',
    'contact.hours': 'Opening Hours',
    'contact.hours.weekdays': 'Monday - Friday: 8:00 - 18:00',
    'contact.hours.saturday': 'Saturday: 9:00 - 14:00',
    'contact.hours.sunday': 'Sunday: Closed',
    'contact.map.title': 'Location Map',
    'contact.map.subtitle': 'Dubnica nad Váhom, Slovakia',
    'contact.success.title': 'Message Sent!',
    'contact.success.description': 'We will contact you as soon as possible.',
    
    // Footer
    'footer.contact': 'Contact',
    'footer.address': 'Štúrova 1532/92, 018 41 Dubnica nad Váhom, Slovakia',
    'footer.follow': 'Follow Us',
    'footer.rights': 'All rights reserved.',
    'footer.description': 'Professional physiotherapy with global experience in the heart of Slovakia.',
    
    // Body parts for interactive map
    'body.head': 'Head',
    'body.neck': 'Neck',
    'body.shoulder': 'Shoulder',
    'body.arm': 'Arm',
    'body.back': 'Back',
    'body.knee': 'Knee',
    'body.ankle': 'Ankle',
    'body.elbow': 'Elbow',
    'body.wrist': 'Wrist',
    'body.hip': 'Hip',
    'body.leg': 'Leg',
    
    // Conditions
    'conditions.headaches': 'Headaches',
    'conditions.neck-pain': 'Neck Pain',
    'conditions.shoulder-impingement': 'Shoulder Impingement',
    'conditions.back-pain': 'Back Pain',
    'conditions.knee-pain': 'Knee Pain',
    'conditions.ankle-sprain': 'Ankle Sprain',
    
    // Patient Resources
    'resources.title': 'Patient Resources',
    'resources.subtitle': 'Useful information and guides to support your recovery and overall health',
    'resources.newsletter.title': 'Subscribe to our newsletter',
    'resources.newsletter.subtitle': 'Get the latest health tips, exercises and information delivered directly to your inbox.',
    'resources.newsletter.email': 'Your email',
    'resources.newsletter.subscribe': 'Subscribe',
    'resources.read-more': 'Read more',
    
    // Interactive Map
    'map.select-body-part': 'Select a body part',
    'map.select-instruction': 'Click on any body part in the diagram to see specific conditions we treat in that area.',
    'map.conditions-title': 'Conditions we treat:',
    'map.consultation-note': 'Each condition requires an individual approach. Contact us for a personal consultation and to create your treatment plan.',
    'map.instructions': 'Click on a body part to learn more about conditions we treat',
    
    // Cookie Consent
    'cookies.title': 'Cookies',
    'cookies.message': 'We use cookies to improve your browsing experience and analyze our traffic. By clicking "Accept", you consent to our use of cookies.',
    'cookies.accept': 'Accept All',
    'cookies.decline': 'Decline',
    
    // GDPR Compliance
    'gdpr.title': 'GDPR Compliance',
    'gdpr.description': 'Information about how we process your personal data in accordance with GDPR',
    'gdpr.subtitle': 'Your privacy is our priority. Learn how we process your personal data.',
    'gdpr.last-updated': 'Last updated',
    'gdpr.data-controller.title': 'Data Controller',
    'gdpr.data-controller.content': '<p>The controller of your personal data is <strong>Šport & Body Terapia</strong>, located in Dubnica nad Váhom, Slovakia.</p><p>Contact: info@sportbodyterapia.sk</p>',
    'gdpr.data-collected.title': 'What data we collect',
    'gdpr.data-collected.content': '<ul><li>Name and surname</li><li>Email address</li><li>Phone number</li><li>Health information relevant to treatment</li><li>Visit and treatment data</li></ul>',
    'gdpr.legal-basis.title': 'Legal basis for processing',
    'gdpr.legal-basis.content': '<p>We process your data based on:</p><ul><li><strong>Consent</strong> - for marketing communications</li><li><strong>Contract performance</strong> - for providing healthcare services</li><li><strong>Legitimate interest</strong> - for improving our services</li></ul>',
    'gdpr.your-rights.title': 'Your rights',
    'gdpr.your-rights.content': '<ul><li>Right to access data</li><li>Right to rectify data</li><li>Right to erasure of data</li><li>Right to data portability</li><li>Right to restrict processing</li><li>Right to object</li></ul>',
    'gdpr.contact.title': 'Contact for GDPR questions',
    'gdpr.contact.description': 'For any questions regarding personal data processing, you can contact us:',
    
    // Privacy Policy
    'privacy.title': 'Privacy Policy',
    'privacy.description': 'Information about our privacy practices and personal data processing',
    'privacy.subtitle': 'Transparent information about how we protect your privacy',
    'privacy.last-updated': 'Last updated',
    'privacy.data-collection.title': 'Data Collection',
    'privacy.data-collection.content': '<p>We collect only data necessary to provide our services:</p><ul><li>Identification data (name, address)</li><li>Contact data (phone, email)</li><li>Health data relevant to treatment</li><li>Technical data (IP address, cookies)</li></ul>',
    'privacy.data-usage.title': 'Data Usage',
    'privacy.data-usage.content': '<p>We use your data exclusively for:</p><ul><li>Providing healthcare services</li><li>Communication with patients</li><li>Improving service quality</li><li>Compliance with legal obligations</li></ul>',
    'privacy.data-sharing.title': 'Data Sharing',
    'privacy.data-sharing.content': '<p>We do not share your data with third parties, except:</p><ul><li>With patient consent</li><li>For health purposes (referrals to specialists)</li><li>Based on legal obligation</li></ul>',
    'privacy.data-security.title': 'Data Security',
    'privacy.data-security.content': '<p>We implement strict security measures:</p><ul><li>Data encryption</li><li>Regular security audits</li><li>Limited data access</li><li>Secure document storage</li></ul>',
    'privacy.data-retention.title': 'Data Retention',
    'privacy.data-retention.content': '<p>We retain data for:</p><ul><li>Health records: according to applicable legislation</li><li>Contact data: until consent withdrawal</li><li>Technical data: maximum 2 years</li></ul>',
    'privacy.cookies.title': 'Cookies',
    'privacy.cookies.content': '<p>We use cookies for:</p><ul><li>Ensuring website functionality</li><li>Traffic analysis</li><li>Improving user experience</li></ul><p>Detailed information can be found in our <a href="/cookie-policy" class="text-brand-teal">Cookie Policy</a>.</p>',
    
    // Terms of Service
    'terms.title': 'Terms of Service',
    'terms.description': 'Terms and conditions for using our services and website',
    'terms.subtitle': 'Rules and conditions for using our services',
    'terms.last-updated': 'Last updated',
    'terms.acceptance.title': 'Acceptance of Terms',
    'terms.acceptance.content': '<p>By using our services, you agree to these terms of service. If you disagree with any part, please do not use our services.</p>',
    'terms.services.title': 'Our Services',
    'terms.services.content': '<p>We provide:</p><ul><li>Physiotherapy services</li><li>Rehabilitation programs</li><li>Health consultation</li><li>Prevention programs</li></ul><p>All services are provided by qualified professionals.</p>',
    'terms.responsibilities.title': 'Client Responsibilities',
    'terms.responsibilities.content': '<ul><li>Providing accurate health information</li><li>Following therapeutic recommendations</li><li>Timely appointment cancellations</li><li>Payment for services rendered</li></ul>',
    'terms.liability.title': 'Limitation of Liability',
    'terms.liability.content': '<p>Our liability is limited to:</p><ul><li>Providing services with professional care</li><li>Compliance with applicable standards</li><li>Protection of confidential information</li></ul><p>We are not responsible for treatment outcomes that depend on individual factors.</p>',
    'terms.modifications.title': 'Changes to Terms',
    'terms.modifications.content': '<p>We reserve the right to modify these terms. We will inform about changes:</p><ul><li>On our website</li><li>By email to registered clients</li><li>In our clinic</li></ul>',
    
    // Medical Disclaimer
    'medical.title': 'Medical Disclaimer',
    'medical.description': 'Important information about our health services and limitations',
    'medical.subtitle': 'Important information before using our services',
    'medical.last-updated': 'Last updated',
    'medical.important-notice.title': 'Important Notice',
    'medical.important-notice.content': 'This is not a substitute for medical diagnosis or treatment. For serious health problems, consult your doctor.',
    'medical.disclaimer.title': 'Medical Disclaimer',
    'medical.disclaimer.content': '<p>Information on this site is for informational purposes only and is not intended for:</p><ul><li>Diagnosing health conditions</li><li>Medical advice</li><li>Replacing consultation with a doctor</li><li>Prescribing medications or treatments</li></ul>',
    'medical.professional-relationship.title': 'Professional Relationship',
    'medical.professional-relationship.content': '<p>Visiting our website does not create a doctor-patient relationship. A therapeutic relationship is established only after:</p><ul><li>Personal consultation</li><li>Health assessment</li><li>Written patient consent</li></ul>',
    'medical.emergency.title': 'Emergency Situations',
    'medical.emergency.content': '<p><strong>In case of medical emergency, call 155 or contact the nearest medical facility.</strong></p><p>Our services are not intended for acute health conditions.</p>',
    'medical.treatment-results.title': 'Treatment Results',
    'medical.treatment-results.content': '<p>Physiotherapy results may vary depending on:</p><ul><li>Individual health condition</li><li>Problem severity</li><li>Adherence to therapeutic recommendations</li><li>Overall patient health</li></ul><p>We do not guarantee specific treatment outcomes.</p>',
    'medical.individual-assessment.title': 'Individual Assessment',
    'medical.individual-assessment.content': '<p>Each patient is unique and requires an individual approach. Recommendations and exercises must always be adapted to the specific condition and patient needs.</p>',
    
    // Cookie Policy
    'cookies.policy.title': 'Cookie Policy',
    'cookies.policy.description': 'Information about how we use cookies on our website',
    'cookies.policy.subtitle': 'Detailed information about the cookies we use',
    'cookies.policy.last-updated': 'Last updated',
    'cookies.what-are.title': 'What are cookies?',
    'cookies.what-are.content': 'Cookies are small text files stored in your browser when you visit a website. They help us ensure site functionality and improve your user experience.',
    'cookies.types.title': 'Types of cookies',
    'cookies.necessary.title': 'Necessary cookies',
    'cookies.necessary.content': '<p>These cookies are essential for the basic functionality of the website and cannot be disabled.</p><ul><li>Login and authentication</li><li>Security features</li><li>Basic navigation functions</li></ul>',
    'cookies.analytics.title': 'Analytics cookies',
    'cookies.analytics.content': '<p>Help us understand how visitors use our site.</p><ul><li>Google Analytics</li><li>Traffic statistics</li><li>Site usage analysis</li></ul>',
    'cookies.functional.title': 'Functional cookies',
    'cookies.functional.content': '<p>Improve website functionality and personalization.</p><ul><li>Language preferences</li><li>Page layout</li><li>User settings</li></ul>',
    'cookies.management.title': 'Cookie Management',
    'cookies.management.content': '<p>You can manage cookies in the following ways:</p><ul><li><strong>Browser settings:</strong> Most browsers allow blocking or deleting cookies</li><li><strong>Our settings:</strong> You can adjust your cookie preferences</li><li><strong>Automatic deletion:</strong> You can set cookies to delete automatically</li></ul><p>Please note that disabling cookies may affect website functionality.</p>',
    
    // Footer policy links
    'footer.policies': 'Policies',
    'footer.gdpr': 'GDPR',
    'footer.privacy': 'Privacy Policy',
    'footer.terms': 'Terms of Service',
    'footer.medical-disclaimer': 'Medical Disclaimer',
    'footer.cookies': 'Cookie Policy'
  }
};

export const LanguageProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>('sk'); // Default to Slovak

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.sk] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
};
