
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import { useLanguage } from '@/contexts/LanguageContext';
import { ArrowLeft, Clock, User } from 'lucide-react';
import SEO from '@/components/SEO';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

const Article = () => {
  const { articleId } = useParams();
  const { language } = useLanguage();

  const articles = {
    'back-pain-exercises': {
      title: {
        sk: "3 jednoduché cviky na bolesť krížov",
        en: "3 Simple Exercises for Lower Back Pain"
      },
      content: {
        sk: "Bolesť krížov je jedným z najčastejších problémov, s ktorými sa stretávajú pacienti. Tieto jednoduché cviky môžete vykonávať doma a pomôžu vám zmierniť bolesť a posilniť core svaly.",
        en: "Lower back pain is one of the most common problems patients face. These simple exercises can be performed at home and will help relieve pain and strengthen core muscles."
      },
      readTime: "5",
      author: "André Heynes",
      category: {
        sk: "Cvičenia",
        en: "Exercises"
      }
    },
    'understanding-sciatica': {
      title: {
        sk: "Porozumenie ischiasu: Čo potrebujete vedieť",
        en: "Understanding Sciatica: What You Need to Know"
      },
      content: {
        sk: "Ischias môže byť bolestivý a obmedzujúci. V tomto článku sa dozviete o príčinách, príznakoch a efektívnych liečebných možnostiach.",
        en: "Sciatica can be painful and limiting. In this article, you'll learn about causes, symptoms and effective treatment options."
      },
      readTime: "7",
      author: "André Heynes",
      category: {
        sk: "Zdravie",
        en: "Health"
      }
    },
    'headache-management': {
      title: {
        sk: "Ako zvládať bolesti hlavy bez liekov",
        en: "How to Manage Headaches Without Medication"
      },
      content: {
        sk: "Objavte prirodzené spôsoby úľavy od bolesti hlavy pomocou manuálnych techník, relaxácie a úpravy životného štýlu.",
        en: "Discover natural ways to relieve headaches using manual techniques, relaxation and lifestyle changes."
      },
      readTime: "6",
      author: "André Heynes",
      category: {
        sk: "Wellness",
        en: "Wellness"
      }
    },
    'sports-injury-prevention': {
      title: {
        sk: "Prevencia športových zranení",
        en: "Sports Injury Prevention"
      },
      content: {
        sk: "Tipy a stratégie pre športovcov všetkých úrovní na predchádzanie zraneniam a optimalizáciu výkonu.",
        en: "Tips and strategies for athletes of all levels to prevent injuries and optimize performance."
      },
      readTime: "8",
      author: "André Heynes",
      category: {
        sk: "Šport",
        en: "Sports"
      }
    }
  };

  const article = articles[articleId as keyof typeof articles];

  if (!article) {
    return (
      <HelmetProvider>
        <div className="min-h-screen bg-white font-body">
          <SEO title={language === 'sk' ? 'Článok nenájdený' : 'Article Not Found'} />
          <Header />
          <main className="py-20">
            <div className="container mx-auto px-4 text-center">
              <h1 className="text-4xl font-heading font-bold text-brand-charcoal mb-6">
                {language === 'sk' ? 'Článok nenájdený' : 'Article Not Found'}
              </h1>
              <Link to="/" className="text-brand-teal hover:underline">
                {language === 'sk' ? 'Späť na domovskú stránku' : 'Back to Homepage'}
              </Link>
            </div>
          </main>
          <Footer />
        </div>
      </HelmetProvider>
    );
  }

  return (
    <HelmetProvider>
      <div className="min-h-screen bg-white font-body">
        <SEO 
          title={article.title[language]}
          description={article.content[language]}
          type="article"
          canonical={`https://sportbodyterapia.sk/article/${articleId}`}
        />
        <Header />
        <main className="py-20">
          <div className="container mx-auto px-4 max-w-4xl">
            {/* Back Button */}
            <Link to="/#resources" className="inline-flex items-center space-x-2 text-brand-teal hover:text-brand-teal-dark mb-8">
              <ArrowLeft size={20} />
              <span>{language === 'sk' ? 'Späť na zdroje' : 'Back to Resources'}</span>
            </Link>

            <article>
              {/* Article Header */}
              <header className="mb-8">
                <div className="flex items-center space-x-2 text-sm text-gray-500 mb-4">
                  <span className="bg-brand-teal/10 text-brand-teal px-3 py-1 rounded-full font-semibold">
                    {article.category[language]}
                  </span>
                </div>
                
                <h1 className="text-4xl md:text-5xl font-heading font-bold text-brand-charcoal mb-6">
                  {article.title[language]}
                </h1>
                
                <div className="flex items-center space-x-6 text-gray-600">
                  <div className="flex items-center space-x-2">
                    <User size={16} />
                    <span>{article.author}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock size={16} />
                    <span>{article.readTime} {language === 'sk' ? 'min čítania' : 'min read'}</span>
                  </div>
                </div>
              </header>

              {/* Article Content */}
              <Card className="mb-8">
                <CardContent className="p-8">
                  <div className="prose prose-lg max-w-none">
                    <p className="text-lg leading-relaxed text-gray-700 mb-6">
                      {article.content[language]}
                    </p>
                    
                    <div className="bg-brand-teal/5 border-l-4 border-brand-teal p-6 my-8">
                      <p className="text-brand-charcoal">
                        <strong>{language === 'sk' ? 'Poznámka:' : 'Note:'}</strong>{' '}
                        {language === 'sk' 
                          ? 'Toto je ukážkový článok. Obsah bude pridaný neskôr prostredníctvom systému správy obsahu.'
                          : 'This is a sample article. Content will be added later through the content management system.'
                        }
                      </p>
                    </div>

                    <div className="text-center mt-12">
                      <h3 className="text-2xl font-heading font-semibold text-brand-charcoal mb-4">
                        {language === 'sk' ? 'Potrebujete pomoc?' : 'Need Help?'}
                      </h3>
                      <p className="text-gray-600 mb-6">
                        {language === 'sk' 
                          ? 'Kontaktujte nás pre personalizovanú konzultáciu a liečebný plán.'
                          : 'Contact us for a personalized consultation and treatment plan.'
                        }
                      </p>
                      <Button className="bg-brand-teal hover:bg-brand-teal-dark">
                        <Link to="/#contact">
                          {language === 'sk' ? 'Kontaktovať nás' : 'Contact Us'}
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </article>
          </div>
        </main>
        <Footer />
      </div>
    </HelmetProvider>
  );
};

export default Article;
