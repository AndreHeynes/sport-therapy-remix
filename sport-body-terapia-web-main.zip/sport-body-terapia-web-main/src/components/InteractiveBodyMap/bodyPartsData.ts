
export const getConditions = (partId: string, language: string) => {
  const conditionsByPart = {
    head: [
      language === 'sk' ? 'Bolesti hlavy' : 'Headaches',
      language === 'sk' ? 'Migrény' : 'Migraines', 
      language === 'sk' ? 'TMJ poruchy' : 'TMJ Disorders'
    ],
    neck: [
      language === 'sk' ? 'Bolesť krku' : 'Neck Pain',
      language === 'sk' ? 'Cervikálna radikulopatia' : 'Cervical Radiculopathy',
      language === 'sk' ? 'Whiplash' : 'Whiplash'
    ],
    'shoulder-right': [
      language === 'sk' ? 'Bolesť ramena' : 'Shoulder Pain',
      language === 'sk' ? 'Rotátor cuff zranenia' : 'Rotator Cuff Injuries',
      language === 'sk' ? 'Zmrazené rameno' : 'Frozen Shoulder'
    ],
    'arm-left': [
      language === 'sk' ? 'Tenisový lakeť' : 'Tennis Elbow',
      language === 'sk' ? 'Golfový lakeť' : 'Golfers Elbow',
      language === 'sk' ? 'Karpálny tunel' : 'Carpal Tunnel'
    ],
    back: [
      language === 'sk' ? 'Bolesť chrbta' : 'Back Pain',
      language === 'sk' ? 'Ischias' : 'Sciatica',
      language === 'sk' ? 'Diskové herniae' : 'Herniated Disc'
    ],
    'leg-left': [
      language === 'sk' ? 'Natiahnutie/natrhnutie svalu' : 'Muscle strain/tear',
      language === 'sk' ? 'Tendinopatia hamstringov' : 'Hamstring Tendinopathy'
    ],
    'hip-right': [
      language === 'sk' ? 'Bolesť bedra' : 'Hip Pain',
      language === 'sk' ? 'Bursitída bedra' : 'Hip Bursitis',
      language === 'sk' ? 'Artroza bedra' : 'Hip Arthritis'
    ],
    'knee-right': [
      language === 'sk' ? 'Bolesť kolena' : 'Knee Pain',
      language === 'sk' ? 'ACL/MCL zranenia' : 'ACL/MCL Injuries',
      language === 'sk' ? 'Meniskus' : 'Meniscus Tears'
    ],
    'ankle-right': [
      language === 'sk' ? 'Bolesť členka' : 'Ankle Pain',
      language === 'sk' ? 'Podvrtnutie členka' : 'Ankle Sprain',
      language === 'sk' ? 'Achilles tendinitis' : 'Achilles Tendinitis'
    ]
  };
  return conditionsByPart[partId] || [];
};

export const createBodyParts = (t: (key: string) => string, language: string) => [
  { id: 'head', name: t('body.head'), conditions: getConditions('head', language), position: { top: '8%', left: '50%' }},
  { id: 'neck', name: t('body.neck'), conditions: getConditions('neck', language), position: { top: '18%', left: '50%' }},
  { id: 'arm-left', name: t('body.arm'), conditions: getConditions('arm-left', language), position: { top: '35%', left: '30%' }},
  { id: 'shoulder-right', name: t('body.shoulder'), conditions: getConditions('shoulder-right', language), position: { top: '25%', left: '65%' }},
  { id: 'back', name: t('body.back'), conditions: getConditions('back', language), position: { top: '40%', left: '50%' }},
  { id: 'leg-left', name: t('body.leg'), conditions: getConditions('leg-left', language), position: { top: '65%', left: '35%' }},
  { id: 'hip-right', name: t('body.hip'), conditions: getConditions('hip-right', language), position: { top: '55%', left: '60%' }},
  { id: 'knee-right', name: t('body.knee'), conditions: getConditions('knee-right', language), position: { top: '70%', left: '60%' }},
  { id: 'ankle-right', name: t('body.ankle'), conditions: getConditions('ankle-right', language), position: { top: '88%', left: '58%' }}
];
