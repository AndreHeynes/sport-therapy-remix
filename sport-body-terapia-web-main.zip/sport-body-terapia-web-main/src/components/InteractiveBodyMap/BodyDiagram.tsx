
import React from 'react';
import { BodyPart } from './types';

interface BodyDiagramProps {
  bodyParts: BodyPart[];
  selectedPart: string | null;
  onPartClick: (partId: string) => void;
  language: string;
}

const BodyDiagram = ({ bodyParts, selectedPart, onPartClick, language }: BodyDiagramProps) => {
  return (
    <div className="relative">
      <div className="relative w-full max-w-md mx-auto">
        <div className="relative w-full h-96 mx-auto">
          <img
            src="/lovable-uploads/6c4c2762-db38-442f-b6bb-ca445cc69b53.png"
            alt={language === 'sk' ? 'Silueta ľudského tela' : 'Human body silhouette'}
            className="w-full h-full object-contain filter drop-shadow-lg"
          />

          {bodyParts.map((part) => (
            <button
              key={part.id}
              className={`absolute w-6 h-6 rounded-full transform -translate-x-1/2 -translate-y-1/2 transition-all duration-200 ${
                selectedPart === part.id
                  ? 'bg-brand-teal scale-150 shadow-lg z-10 ring-4 ring-brand-teal/30'
                  : 'bg-brand-teal/70 hover:bg-brand-teal hover:scale-125 shadow-md'
              }`}
              style={{
                top: part.position.top,
                left: part.position.left,
              }}
              onClick={() => onPartClick(part.id)}
              aria-label={`${language === 'sk' ? 'Kliknite pre' : 'Click for'} ${part.name}`}
            >
              <span className="sr-only">{part.name}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BodyDiagram;
