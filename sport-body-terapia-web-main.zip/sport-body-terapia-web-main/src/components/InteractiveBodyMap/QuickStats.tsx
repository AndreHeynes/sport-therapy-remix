
import React from 'react';
import { Card } from '@/components/ui/card';

interface QuickStatsProps {
  language: string;
}

const QuickStats = ({ language }: QuickStatsProps) => {
  return (
    <div className="grid grid-cols-2 gap-4">
      <Card className="floating-card glass-card text-center p-4 hover:shadow-glow transition-all duration-300">
        <div className="text-2xl font-bold text-brand-teal animate-glow-pulse">30+</div>
        <div className="text-sm text-gray-600">
          {language === 'sk' ? 'Rôznych stavov' : 'Different conditions'}
        </div>
      </Card>
      <Card className="floating-card glass-card text-center p-4 hover:shadow-glow transition-all duration-300">
        <div className="text-2xl font-bold text-brand-teal animate-glow-pulse">100%</div>
        <div className="text-sm text-gray-600">
          {language === 'sk' ? 'Personalizovaná liečba' : 'Personalized treatment'}
        </div>
      </Card>
    </div>
  );
};

export default QuickStats;
