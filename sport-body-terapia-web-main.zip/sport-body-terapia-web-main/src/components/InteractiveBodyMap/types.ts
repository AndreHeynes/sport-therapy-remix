
export interface BodyPart {
  id: string;
  name: string;
  conditions: string[];
  position: { top: string; left: string };
}
