
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BodyPart } from './types';

interface ConditionDetailsProps {
  selectedBodyPart: BodyPart | null;
  t: (key: string) => string;
  language: string;
}

const ConditionDetails = ({ selectedBodyPart, t, language }: ConditionDetailsProps) => {
  if (selectedBodyPart) {
    return (
      <Card className="border-brand-teal shadow-lg">
        <CardHeader className="bg-brand-teal text-white">
          <CardTitle className="text-2xl font-heading">
            {selectedBodyPart.name}
          </CardTitle>
        </CardHeader>
        <CardContent className="p-6">
          <h4 className="text-lg font-semibold text-brand-charcoal mb-4">
            {t('map.conditions-title')}
          </h4>
          <ul className="space-y-3">
            {selectedBodyPart.conditions.map((condition, index) => (
              <li key={index} className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-brand-teal rounded-full mt-2 flex-shrink-0"></div>
                <span className="text-gray-700">{condition}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600 italic">
              {t('map.consultation-note')}
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-gray-200">
      <CardContent className="p-8 text-center">
        <div className="text-6xl mb-4">🎯</div>
        <h3 className="text-xl font-heading font-semibold text-brand-charcoal mb-4">
          {t('map.select-body-part')}
        </h3>
        <p className="text-gray-600">
          {t('map.select-instruction')}
        </p>
      </CardContent>
    </Card>
  );
};

export default ConditionDetails;
