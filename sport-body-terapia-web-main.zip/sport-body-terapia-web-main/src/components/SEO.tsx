
import { Helmet } from 'react-helmet-async';
import { useLanguage } from '@/contexts/LanguageContext';

interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string;
  canonical?: string;
  ogImage?: string;
  type?: 'website' | 'article';
}

const SEO = ({ 
  title, 
  description, 
  keywords, 
  canonical, 
  ogImage = '/lovable-uploads/3a6c8757-8301-4cad-a960-e64bbe31a2a6.png',
  type = 'website' 
}: SEOProps) => {
  const { language } = useLanguage();
  
  const defaultTitles = {
    sk: 'Šport & Body Terapia - Fyzioterapia Dubnica nad Váhom',
    en: 'Sport & Body Therapy - Physiotherapy Dubnica nad Váhom'
  };
  
  const defaultDescriptions = {
    sk: 'Profesionálna fyzioterapia v Dubnici nad Váhom. André Heynes - 25+ rokov skúseností. Liečba bolestí chrbta, športových zranení a rehabilitácia.',
    en: 'Professional physiotherapy in Dubnica nad Váhom. André Heynes - 25+ years experience. Treatment of back pain, sports injuries and rehabilitation.'
  };
  
  const defaultKeywords = {
    sk: 'fyzioterapia, Dubnica nad Váhom, André Heynes, bolesť chrbta, športové zranenia, rehabilitácia, masáže, manuálna terapia',
    en: 'physiotherapy, Dubnica nad Váhom, André Heynes, back pain, sports injuries, rehabilitation, massage, manual therapy'
  };

  const siteTitle = title ? `${title} | ${defaultTitles[language]}` : defaultTitles[language];
  const siteDescription = description || defaultDescriptions[language];
  const siteKeywords = keywords || defaultKeywords[language];
  const siteUrl = 'https://sportbodyterapia.sk';

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "HealthAndBeautyBusiness",
    "@id": `${siteUrl}/#business`,
    "name": "Šport & Body Terapia",
    "alternateName": "Sport & Body Therapy",
    "description": siteDescription,
    "url": siteUrl,
    "telephone": "+421-XXX-XXX-XXX",
    "email": "info@sportbodyterapia.sk",
    "image": `${siteUrl}${ogImage}`,
    "logo": `${siteUrl}/lovable-uploads/3a6c8757-8301-4cad-a960-e64bbe31a2a6.png`,
    "address": {
      "@type": "PostalAddress",
      "addressLocality": "Dubnica nad Váhom",
      "addressCountry": "SK"
    },
    "geo": {
      "@type": "GeoCoordinates",
      "latitude": "48.9583",
      "longitude": "18.1667"
    },
    "openingHoursSpecification": [
      {
        "@type": "OpeningHoursSpecification",
        "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        "opens": "08:00",
        "closes": "18:00"
      }
    ],
    "sameAs": [
      "https://www.facebook.com/DCAfyzio",
      "https://www.instagram.com/sbt_fyzio"
    ],
    "serviceType": "Physiotherapy",
    "medicalSpecialty": ["Physical Therapy", "Sports Medicine", "Rehabilitation"],
    "hasOfferCatalog": {
      "@type": "OfferCatalog",
      "name": "Physiotherapy Services",
      "itemListElement": [
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service",
            "name": language === 'sk' ? "Muskuloskeletálne poruchy" : "Musculoskeletal Disorders"
          }
        },
        {
          "@type": "Offer", 
          "itemOffered": {
            "@type": "Service",
            "name": language === 'sk' ? "Športové zranenia" : "Sports Injuries"
          }
        },
        {
          "@type": "Offer",
          "itemOffered": {
            "@type": "Service", 
            "name": language === 'sk' ? "Pooperačná rehabilitácia" : "Post-Operative Rehabilitation"
          }
        }
      ]
    }
  };

  return (
    <Helmet>
      {/* Basic Meta Tags */}
      <title>{siteTitle}</title>
      <meta name="description" content={siteDescription} />
      <meta name="keywords" content={siteKeywords} />
      <meta name="author" content="André Heynes" />
      <meta name="robots" content="index, follow" />
      <meta name="language" content={language === 'sk' ? 'Slovak' : 'English'} />
      
      {/* Canonical URL */}
      {canonical && <link rel="canonical" href={canonical} />}
      
      {/* Open Graph Tags */}
      <meta property="og:type" content={type} />
      <meta property="og:title" content={siteTitle} />
      <meta property="og:description" content={siteDescription} />
      <meta property="og:image" content={`${siteUrl}${ogImage}`} />
      <meta property="og:url" content={canonical || siteUrl} />
      <meta property="og:site_name" content="Šport & Body Terapia" />
      <meta property="og:locale" content={language === 'sk' ? 'sk_SK' : 'en_US'} />
      
      {/* Twitter Card Tags */}
      <meta name="twitter:card" content="summary_large_image" />
      <meta name="twitter:title" content={siteTitle} />
      <meta name="twitter:description" content={siteDescription} />
      <meta name="twitter:image" content={`${siteUrl}${ogImage}`} />
      
      {/* Additional Meta Tags */}
      <meta name="format-detection" content="telephone=yes" />
      <meta name="geo.region" content="SK" />
      <meta name="geo.placename" content="Dubnica nad Váhom" />
      <meta name="geo.position" content="48.9583;18.1667" />
      <meta name="ICBM" content="48.9583, 18.1667" />
      
      {/* Structured Data */}
      <script type="application/ld+json">
        {JSON.stringify(structuredData)}
      </script>
    </Helmet>
  );
};

export default SEO;
