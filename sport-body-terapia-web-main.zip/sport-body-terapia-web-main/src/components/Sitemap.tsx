
import React from 'react';

const Sitemap = () => {
  const baseUrl = 'https://sportbodyterapia.sk';
  const currentDate = new Date().toISOString().split('T')[0];
  
  const pages = [
    { url: '/', priority: '1.0', changefreq: 'weekly' },
    { url: '/#about', priority: '0.8', changefreq: 'monthly' },
    { url: '/#services', priority: '0.9', changefreq: 'monthly' },
    { url: '/#resources', priority: '0.7', changefreq: 'weekly' },
    { url: '/#contact', priority: '0.8', changefreq: 'monthly' },
    { url: '/article/back-pain-exercises', priority: '0.6', changefreq: 'monthly' },
    { url: '/article/understanding-sciatica', priority: '0.6', changefreq: 'monthly' },
    { url: '/article/headache-management', priority: '0.6', changefreq: 'monthly' },
    { url: '/article/sports-injury-prevention', priority: '0.6', changefreq: 'monthly' }
  ];

  const sitemapXML = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${pages.map(page => `  <url>
    <loc>${baseUrl}${page.url}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>${page.changefreq}</changefreq>
    <priority>${page.priority}</priority>
  </url>`).join('\n')}
</urlset>`;

  return (
    <div style={{ display: 'none' }}>
      {/* This component generates sitemap data for SEO purposes */}
      <pre>{sitemapXML}</pre>
    </div>
  );
};

export default Sitemap;
