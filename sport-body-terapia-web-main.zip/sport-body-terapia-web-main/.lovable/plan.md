
# Implementation Plan: Enable Lovable Cloud and Build Backend Features

## Overview

This plan covers enabling Lovable Cloud and implementing a complete backend infrastructure including a Blog CMS with admin interface, functional contact form, and newsletter signup - all with proper authentication and security.

---

## Step 1: Enable Lovable Cloud

**What you need to do:**
1. Click the **Cloud** icon in the navigation bar above the preview (looks like a cloud)
2. Click **Enable Cloud** to activate Lovable Cloud for this project
3. This will automatically provision a database, authentication, and edge functions

**Cost:** Free tier includes generous usage for development and testing. You only pay for usage when you go live and exceed free limits.

---

## Step 2: Database Structure

Once Cloud is enabled, I will create the following tables:

### Posts Table (for blog articles)
| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| slug | text | URL-friendly identifier (e.g., "back-pain-exercises") |
| title_sk | text | Slovak title |
| title_en | text | English title |
| content_sk | text | Slovak content (supports rich text/markdown) |
| content_en | text | English content |
| excerpt_sk | text | Slovak excerpt for cards |
| excerpt_en | text | English excerpt |
| category_sk | text | Slovak category |
| category_en | text | English category |
| cover_image | text | Optional cover image URL |
| author | text | Author name |
| read_time | integer | Estimated read time in minutes |
| status | text | "draft" or "published" |
| created_at | timestamp | Creation date |
| updated_at | timestamp | Last update date |

### Contact Submissions Table
| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| name | text | Sender name |
| email | text | Sender email |
| phone | text | Optional phone |
| message | text | Message content |
| created_at | timestamp | Submission date |
| is_read | boolean | Read status |

### Newsletter Subscribers Table
| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| email | text | Subscriber email (unique) |
| subscribed_at | timestamp | Subscription date |
| is_active | boolean | Subscription status |

---

## Step 3: Admin Authentication

I will set up email-based authentication for the admin area:

1. **Admin Login Page** (`/admin/login`)
   - Simple email/password login form
   - Protected admin routes

2. **Your Admin Email**
   - You will manually add your email as an admin user via Supabase dashboard
   - Only authenticated users can access `/admin/*` routes

---

## Step 4: Admin Interface

A complete admin panel at `/admin` with:

### Dashboard (`/admin`)
- Overview of recent posts, unread messages, subscriber count
- Quick links to create new post, view messages

### Blog Management (`/admin/posts`)
- List all posts (drafts and published)
- Create new post button
- Edit/Delete existing posts
- Toggle publish status

### Blog Editor (`/admin/posts/new` and `/admin/posts/:id/edit`)
- **Title fields** (SK/EN)
- **Rich text editor** for content (SK/EN)
- **Excerpt fields** (SK/EN)
- **Category fields** (SK/EN)
- **Cover image** upload
- **Author name**
- **Read time** (auto-calculated or manual)
- **Preview button** - see how it looks before publishing
- **Save as Draft** or **Publish** buttons

### Contact Messages (`/admin/messages`)
- List all contact form submissions
- Mark as read/unread
- View message details
- Delete old messages

### Newsletter Subscribers (`/admin/subscribers`)
- List all subscribers
- Export as CSV
- View subscription stats

---

## Step 5: Update Public Pages

### Article Page (`/article/:slug`)
- Fetch article from database by slug
- Display content in current language
- Fall back to 404 if not found

### Patient Resources Section
- Fetch published posts from database
- Display as cards with excerpt, category, read time
- Link to full article

### Contact Form
- Submit to database instead of mailto
- Server-side validation via edge function
- Optional: Send email notification

### Newsletter Form
- Submit to database
- Prevent duplicate subscriptions
- Show success/error feedback

---

## Step 6: File Structure

New files to be created:

```text
src/
  integrations/
    supabase/
      client.ts          (auto-generated)
      types.ts           (auto-generated)
  
  pages/
    admin/
      Login.tsx          (Admin login page)
      Dashboard.tsx      (Admin dashboard)
      Posts.tsx          (Post list)
      PostEditor.tsx     (Create/edit post)
      Messages.tsx       (Contact submissions)
      Subscribers.tsx    (Newsletter list)
  
  components/
    admin/
      AdminLayout.tsx    (Admin wrapper with sidebar)
      PostForm.tsx       (Reusable post form)
      RichTextEditor.tsx (Content editor component)
      ProtectedRoute.tsx (Auth guard)
  
  hooks/
    useAuth.ts           (Authentication hook)

supabase/
  migrations/
    (database schema migrations - auto-managed)
```

---

## Step 7: Security

1. **Row Level Security (RLS)** policies:
   - Posts: Anyone can read published posts; only authenticated admins can create/edit/delete
   - Contact submissions: Only authenticated admins can read
   - Newsletter: Only authenticated admins can read; anyone can insert (subscribe)

2. **Protected Routes**: Admin pages require authentication

3. **Input Validation**: Server-side validation on all form submissions

---

## What You Will Be Able to Do

Once complete, your workflow for adding a new blog post will be:

1. Go to `yoursite.com/admin`
2. Log in with your email/password
3. Click "New Post"
4. Fill in the form:
   - Paste your text in Slovak and English
   - Add a cover image (optional)
   - Set category and read time
5. Click "Preview" to see how it looks
6. Click "Publish" when ready
7. The post immediately appears on your public site

---

## Timeline

| Phase | Tasks | Estimated Effort |
|-------|-------|------------------|
| 1 | Enable Cloud, create database tables | ~10 minutes |
| 2 | Admin authentication and protected routes | ~15 minutes |
| 3 | Admin dashboard and layout | ~15 minutes |
| 4 | Blog post editor with preview | ~20 minutes |
| 5 | Update public Article and Resources pages | ~15 minutes |
| 6 | Contact form backend | ~10 minutes |
| 7 | Newsletter backend | ~10 minutes |
| 8 | Security policies and testing | ~15 minutes |

---

## Next Step

Please click the **Cloud** icon in the navigation bar and enable Lovable Cloud. Once enabled, I will proceed with the implementation.
